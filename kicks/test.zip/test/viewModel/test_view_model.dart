import 'package:http/testing.dart';
import 'package:kicks/model/user.dart';
import 'package:kicks/service/auth_api.dart';
import 'package:mocktail/mocktail.dart';


 class MockAuthApi extends Mock implements AuthApi{}


 User